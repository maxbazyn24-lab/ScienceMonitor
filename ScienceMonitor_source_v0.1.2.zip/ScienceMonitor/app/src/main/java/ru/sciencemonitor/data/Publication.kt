package ru.sciencemonitor.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "publications")
data class Publication(
    @PrimaryKey val deduplicationKey: String,
    val title: String,
    val authors: String = "",
    val publicationYear: Int? = null,
    val journal: String = "",
    val doi: String? = null,
    val abstractText: String = "",
    val language: String? = null,
    val landingPageUrl: String? = null,
    val source: String,
    val relevance: String = "UNASSESSED",
    val aiSummary: String? = null,
    val aiAnalysisStatus: String = "NOT_ANALYZED",
    val dateAddedUtc: Long = System.currentTimeMillis()
)
