package ru.sciencemonitor.data

import ru.sciencemonitor.network.ApiFactory

class PublicationRepository(private val dao: PublicationDao) {

    suspend fun searchOpenAlex(query: String): Int {
        val response = ApiFactory.openAlex.searchWorks(query = query)
        val publications = response.results.mapNotNull { work ->
            val title = work.title?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val doi = work.doi?.removePrefix("https://doi.org/")
            val key = doi?.lowercase() ?: title.trim().lowercase()

            Publication(
                deduplicationKey = key,
                title = title,
                authors = work.authorships.mapNotNull { it.author?.display_name }
                    .joinToString("; "),
                publicationYear = work.publication_year,
                journal = work.primary_location?.source?.display_name.orEmpty(),
                doi = doi,
                landingPageUrl = work.id,
                source = "OpenAlex"
            )
        }
        dao.insertAll(publications)
        return publications.size
    }

    suspend fun searchCrossref(query: String): Int {
        val response = ApiFactory.crossref.searchWorks(query = query)
        val publications = response.message.items.mapNotNull { work ->
            val title = work.title?.firstOrNull()?.takeIf { it.isNotBlank() }
                ?: return@mapNotNull null
            val doi = work.DOI
            val key = doi?.lowercase() ?: title.trim().lowercase()
            val year = work.`published`?.`date-parts`?.firstOrNull()?.firstOrNull()

            Publication(
                deduplicationKey = key,
                title = title,
                authors = work.author.orEmpty().mapNotNull {
                    listOfNotNull(it.given, it.family).joinToString(" ").ifBlank { null }
                }.joinToString("; "),
                publicationYear = year,
                journal = work.container_title?.firstOrNull().orEmpty(),
                doi = doi,
                landingPageUrl = work.URL,
                abstractText = work.abstract.orEmpty(),
                source = "Crossref"
            )
        }
        dao.insertAll(publications)
        return publications.size
    }
}
