package ru.sciencemonitor.network

import retrofit2.http.GET
import retrofit2.http.Query

interface OpenAlexService {
    @GET("works")
    suspend fun searchWorks(
        @Query("search") query: String,
        @Query("per-page") perPage: Int = 50,
        @Query("sort") sort: String = "publication_date:desc"
    ): OpenAlexResponse
}

interface CrossrefService {
    @GET("works")
    suspend fun searchWorks(
        @Query("query") query: String,
        @Query("rows") rows: Int = 50,
        @Query("sort") sort: String = "published",
        @Query("order") order: String = "desc"
    ): CrossrefResponse
}

data class OpenAlexResponse(val results: List<OpenAlexWork> = emptyList())
data class OpenAlexWork(
    val id: String? = null,
    val doi: String? = null,
    val title: String? = null,
    val publication_year: Int? = null,
    val publication_date: String? = null,
    val authorships: List<OpenAlexAuthorship> = emptyList(),
    val primary_location: OpenAlexLocation? = null,
    val abstract_inverted_index: Map<String, List<Int>>? = null
)
data class OpenAlexAuthorship(val author: OpenAlexAuthor? = null)
data class OpenAlexAuthor(val display_name: String? = null)
data class OpenAlexLocation(val source: OpenAlexSource? = null)
data class OpenAlexSource(val display_name: String? = null)

data class CrossrefResponse(val message: CrossrefMessage = CrossrefMessage())
data class CrossrefMessage(val items: List<CrossrefWork> = emptyList())
data class CrossrefWork(
    val DOI: String? = null,
    val title: List<String>? = null,
    val author: List<CrossrefAuthor>? = null,
    val published: CrossrefDate? = null,
    val container_title: List<String>? = null,
    val URL: String? = null,
    val abstract: String? = null
)
data class CrossrefAuthor(val given: String? = null, val family: String? = null)
data class CrossrefDate(val `date-parts`: List<List<Int>>? = null)
