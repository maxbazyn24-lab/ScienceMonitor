package ru.sciencemonitor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ru.sciencemonitor.data.SearchScheduler

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SearchScheduler.scheduleWeekly(this)

        setContent {
            MaterialTheme {
                ScienceMonitorHome()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ScienceMonitorHome() {
    var status by remember { mutableStateOf("Ожидает первого поиска") }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Science Monitor") })
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("Научный мониторинг", style = MaterialTheme.typography.headlineSmall)
                Text(
                    "Текущая тема: Palaemon macrodactylus и экология Азовского моря",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            item {
                ElevatedCard {
                    Column(Modifier.padding(16.dp)) {
                        Text("Автоматический поиск", style = MaterialTheme.typography.titleMedium)
                        Text("Каждый понедельник. Фоновый запуск может задерживаться Android.")
                        Spacer(Modifier.height(8.dp))
                        Text("Статус: $status")
                        Button(onClick = { status = "Ручной запуск будет подключён на следующем этапе" }) {
                            Text("Запустить поиск")
                        }
                    }
                }
            }
            item {
                ElevatedCard {
                    Column(Modifier.padding(16.dp)) {
                        Text("Источники", style = MaterialTheme.typography.titleMedium)
                        Text("OpenAlex · Crossref · Semantic Scholar · eLIBRARY.RU")
                        Text(
                            "Подключение eLIBRARY требует отдельной проверки разрешённого доступа.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            item {
                ElevatedCard {
                    Column(Modifier.padding(16.dp)) {
                        Text("Библиотека", style = MaterialTheme.typography.titleMedium)
                        Text("Локальная база публикаций будет подключена следующим этапом.")
                        Text("Экспорт XLSX и ИИ-анализ также запланированы.")
                    }
                }
            }
        }
    }
}
