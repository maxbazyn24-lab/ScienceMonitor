package ru.sciencemonitor.sources

/**
 * eLIBRARY.RU connector placeholder.
 *
 * Before implementation, verify the currently permitted access method,
 * terms of use, authentication requirements, rate limits and availability
 * of an official API or export mechanism.
 *
 * Do not implement CAPTCHA bypass, session theft, or access-control evasion.
 */
interface ElibrarySource {
    suspend fun search(query: String): List<ElibraryRecord>
}

data class ElibraryRecord(
    val title: String,
    val authors: String?,
    val year: Int?,
    val journal: String?,
    val doi: String?,
    val landingPageUrl: String?,
    val abstractText: String?
)
