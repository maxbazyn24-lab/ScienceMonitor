package ru.sciencemonitor.data

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class WeeklySearchWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        return try {
            val dao = ScienceDatabase.get(applicationContext).publicationDao()
            val repository = PublicationRepository(dao)

            // Начальный поисковый запрос. В следующих версиях он будет
            // формироваться из редактируемых тематических профилей.
            repository.searchOpenAlex("Palaemon macrodactylus")
            repository.searchCrossref("Palaemon macrodactylus")

            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
