package ru.sciencemonitor.network

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ApiFactory {
    val openAlex: OpenAlexService by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.openalex.org/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(OpenAlexService::class.java)
    }

    val crossref: CrossrefService by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.crossref.org/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(CrossrefService::class.java)
    }
}
