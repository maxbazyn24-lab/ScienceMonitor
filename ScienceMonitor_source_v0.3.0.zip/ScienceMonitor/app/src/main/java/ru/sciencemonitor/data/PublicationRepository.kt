package ru.sciencemonitor.data
import ru.sciencemonitor.network.ApiFactory

class PublicationRepository(private val dao:PublicationDao) {
 suspend fun search(query:String, enabled:Set<String>, limit:Int=50):SearchReport {
  require(query.isNotBlank()) { "Введите поисковый запрос" }
  val counts=linkedMapOf<String,Int>(); val errors=mutableListOf<String>()
  if (enabled.isEmpty()) return SearchReport(0, emptyMap(), listOf("В настройках не включён ни один источник поиска"))
  suspend fun run(source:String, block:suspend()->List<Publication>) {
   if(source !in enabled) return
   try { val rows=block().take(limit); dao.insertAll(rows); counts[source]=rows.size }
   catch(e:Exception) { errors += "$source: ${e.message?.take(120) ?: "ошибка соединения"}" }
  }
  run("OpenAlex") { ApiFactory.openAlex.searchWorks(query,limit).results.mapNotNull { w ->
   val title=w.title?.takeIf{it.isNotBlank()}?:return@mapNotNull null; val doi=w.doi?.substringAfter("doi.org/")
   Publication(doi?.lowercase()?:title.lowercase().trim(),title,w.authorships.mapNotNull{it.author?.display_name}.joinToString("; "),w.publication_year,w.primary_location?.source?.display_name.orEmpty(),doi,landingPageUrl=doi?.let{"https://doi.org/$it"} ?: w.id,source="OpenAlex")
  } }
  run("Crossref") { ApiFactory.crossref.searchWorks(query,limit).message.items.mapNotNull { w ->
   val title=w.title?.firstOrNull()?.takeIf{it.isNotBlank()}?:return@mapNotNull null; val doi=w.DOI
   Publication(doi?.lowercase()?:title.lowercase().trim(),title,w.author.orEmpty().mapNotNull{listOfNotNull(it.given,it.family).joinToString(" ").ifBlank{null}}.joinToString("; "),w.`published`?.`date-parts`?.firstOrNull()?.firstOrNull(),w.container_title?.firstOrNull().orEmpty(),doi,w.abstract.orEmpty(),landingPageUrl=w.URL,source="Crossref")
  } }
  run("Europe PMC") { ApiFactory.europePmc.search(query,pageSize=limit).resultList.result.mapNotNull { w ->
   val title=w.title?.takeIf{it.isNotBlank()}?:return@mapNotNull null; val doi=w.doi
   Publication(doi?.lowercase()?:w.pmid?.let{"pmid:$it"}?:title.lowercase().trim(),title,w.authorString.orEmpty(),w.firstPublicationDate?.take(4)?.toIntOrNull(),w.journalTitle.orEmpty(),doi,w.abstractText.orEmpty(),landingPageUrl=when { !w.pmcid.isNullOrBlank()->"https://europepmc.org/articles/${w.pmcid}"; !doi.isNullOrBlank()->"https://doi.org/$doi"; !w.pmid.isNullOrBlank()->"https://pubmed.ncbi.nlm.nih.gov/${w.pmid}/"; else->null },source="Europe PMC")
  } }
  run("Semantic Scholar") { ApiFactory.semanticScholar.search(query,limit).data.mapNotNull { w ->
   val title=w.title?.takeIf{it.isNotBlank()}?:return@mapNotNull null
   val doi=w.externalIds?.get("DOI")
   Publication(doi?.lowercase()?:title.lowercase().trim(),title,w.authors.mapNotNull{it.name}.joinToString("; "),w.year,w.venue.orEmpty(),doi,w.abstract.orEmpty(),landingPageUrl=w.url ?: doi?.let{"https://doi.org/$it"},source="Semantic Scholar")
  } }
  val total=counts.values.sum()
  return SearchReport(total,counts,errors)
 }
}
data class SearchReport(val received:Int,val bySource:Map<String,Int>,val errors:List<String>)
