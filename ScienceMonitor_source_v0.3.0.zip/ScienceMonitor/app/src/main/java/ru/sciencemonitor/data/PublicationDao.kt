package ru.sciencemonitor.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PublicationDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(items: List<Publication>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(item: Publication)

    @Query("SELECT * FROM publications ORDER BY dateAddedUtc DESC")
    fun observeAll(): Flow<List<Publication>>

    @Query("SELECT COUNT(*) FROM publications")
    suspend fun count(): Int

    @Query("SELECT * FROM publications WHERE deduplicationKey = :key LIMIT 1")
    suspend fun findByKey(key: String): Publication?

    @Query("DELETE FROM publications")
    suspend fun clearAll()
}
