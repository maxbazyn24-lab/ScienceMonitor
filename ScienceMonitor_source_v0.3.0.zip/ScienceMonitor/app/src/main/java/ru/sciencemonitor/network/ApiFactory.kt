package ru.sciencemonitor.network
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
object ApiFactory {
 private fun retrofit(url:String)=Retrofit.Builder().baseUrl(url).addConverterFactory(GsonConverterFactory.create()).build()
 val openAlex:OpenAlexService by lazy { retrofit("https://api.openalex.org/").create(OpenAlexService::class.java) }
 val crossref:CrossrefService by lazy { retrofit("https://api.crossref.org/").create(CrossrefService::class.java) }
 val europePmc:EuropePmcService by lazy { retrofit("https://www.ebi.ac.uk/europepmc/webservices/rest/").create(EuropePmcService::class.java) }
 val semanticScholar:SemanticScholarService by lazy { retrofit("https://api.semanticscholar.org/graph/v1/").create(SemanticScholarService::class.java) }
}
