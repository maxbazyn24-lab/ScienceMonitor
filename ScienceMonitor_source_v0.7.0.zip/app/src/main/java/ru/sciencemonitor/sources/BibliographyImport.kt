package ru.sciencemonitor.sources

import ru.sciencemonitor.data.Publication
import java.nio.charset.Charset
import java.text.Normalizer
import java.util.Locale

/** Imports user-selected bibliography exports. It never reads browser cookies or site sessions. */
object BibliographyImport {
    fun parse(bytes: ByteArray, fileName: String): List<Publication> {
        val text = decode(bytes)
        val lower = fileName.lowercase(Locale.ROOT)
        val rows = when {
            lower.endsWith(".ris") || text.contains("TY  -") -> parseRis(text)
            lower.endsWith(".bib") || text.contains("@article", ignoreCase = true) || text.contains("@inproceedings", ignoreCase = true) -> parseBibtex(text)
            lower.endsWith(".csv") || lower.endsWith(".txt") -> parseCsv(text)
            else -> throw IllegalArgumentException("Формат не распознан. Поддерживаются RIS, BibTeX и CSV.")
        }
        return rows.mapNotNull { it.toPublication() }.distinctBy { it.deduplicationKey }
    }

    private fun decode(bytes: ByteArray): String {
        val utf8 = bytes.toString(Charsets.UTF_8).removePrefix("\uFEFF")
        if (!utf8.contains('\uFFFD')) return utf8
        return try { String(bytes, Charset.forName("windows-1251")) }
        catch (_: Exception) { utf8 }
    }

    private data class Row(val title:String="", val authors:String="", val year:Int?=null, val journal:String="", val doi:String="", val url:String="", val abstractText:String="") {
        fun toPublication(): Publication? {
            val cleanTitle = clean(title)
            if (cleanTitle.isBlank()) return null
            val normalizedDoi = doi.trim().removePrefix("https://doi.org/").removePrefix("http://doi.org/").takeIf { it.isNotBlank() }
            val key = normalizedDoi?.let { "doi:${it.lowercase(Locale.ROOT)}" }
                ?: "title:${Normalizer.normalize(cleanTitle.lowercase(Locale.ROOT), Normalizer.Form.NFKC).replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()}:${year ?: ""}"
            return Publication(key, cleanTitle, clean(authors), year, clean(journal), normalizedDoi, clean(abstractText), landingPageUrl=url.trim().ifBlank { normalizedDoi?.let { "https://doi.org/$it" } }, source="eLIBRARY / импорт файла")
        }
    }

    private fun parseRis(text:String):List<Row> {
        val rows= mutableListOf<Row>(); var fields= linkedMapOf<String,MutableList<String>>()
        fun flush(){ if(fields.isNotEmpty()){ val year=fields["PY"]?.firstOrNull()?.take(4)?.toIntOrNull() ?: fields["Y1"]?.firstOrNull()?.take(4)?.toIntOrNull(); rows+=Row(fields["TI"]?.firstOrNull() ?: fields["T1"]?.firstOrNull().orEmpty(),fields["AU"].orEmpty().joinToString("; "),year,fields["JO"]?.firstOrNull() ?: fields["JF"]?.firstOrNull() ?: fields["T2"]?.firstOrNull().orEmpty(),fields["DO"]?.firstOrNull().orEmpty(),fields["UR"]?.firstOrNull().orEmpty(),fields["AB"]?.firstOrNull().orEmpty()) }; fields=linkedMapOf() }
        text.lineSequence().forEach { line ->
            val match=Regex("^([A-Z0-9]{2})  - (.*)$").find(line)
            if(match!=null){ val tag=match.groupValues[1]; val value=match.groupValues[2].trim(); if(tag=="TY" && fields.isNotEmpty()) flush(); if(tag!="ER" && tag!="TY") fields.getOrPut(tag){ mutableListOf() }.add(value); if(tag=="ER") flush() }
        }; flush(); return rows
    }

    private fun parseBibtex(text: String): List<Row> {
        val bodies = mutableListOf<String>()
        var searchFrom = 0
        while (searchFrom < text.length) {
            val at = text.indexOf('@', searchFrom)
            if (at < 0) break
            val open = text.indexOf('{', at)
            if (open < 0) break
            var depth = 1
            var i = open + 1
            var quoted = false
            var escaped = false
            while (i < text.length && depth > 0) {
                val ch = text[i]
                if (escaped) escaped = false
                else if (ch == '\\' && quoted) escaped = true
                else if (ch == '"') quoted = !quoted
                else if (!quoted && ch == '{') depth++
                else if (!quoted && ch == '}') depth--
                i++
            }
            if (depth == 0) bodies += text.substring(open + 1, i - 1)
            searchFrom = i.coerceAtLeast(at + 1)
        }
        return bodies.mapNotNull { body ->
            val comma = body.indexOf(',')
            if (comma < 0) return@mapNotNull null
            val fieldsText = body.substring(comma + 1)
            val fields = linkedMapOf<String, String>()
            Regex("(?is)([a-zA-Z]+)\\s*=\\s*(\\{(?:[^{}]|\\{[^{}]*\\})*\\}|\"(?:\\\\.|[^\"])*\"|[^,\\n]+)")
                .findAll(fieldsText).forEach { match ->
                    fields[match.groupValues[1].lowercase(Locale.ROOT)] = match.groupValues[2].trim().trim('{', '}', '"')
                }
            Row(
                fields["title"].orEmpty(),
                fields["author"].orEmpty().replace(Regex("\\s+and\\s+", RegexOption.IGNORE_CASE), "; "),
                fields["year"]?.toIntOrNull(),
                fields["journal"] ?: fields["booktitle"].orEmpty(),
                fields["doi"].orEmpty(),
                fields["url"].orEmpty(),
                fields["abstract"].orEmpty()
            )
        }
    }

    private fun parseCsv(text:String):List<Row> {
        val lines=text.lineSequence().filter { it.isNotBlank() }.toList(); if(lines.size<2) return emptyList()
        val delimiter= listOf(';','\t',',').maxByOrNull { d -> lines.first().count { it==d } } ?: ';'
        val headers=splitCsv(lines.first(),delimiter).map { normalizeHeader(it) }
        fun col(vararg names:String)=headers.indexOfFirst { h -> names.any { h.contains(it) } }
        val ti=col("title","название","заглавие","наименование"); val au=col("author","автор"); val yr=col("year","год"); val jo=col("journal","журнал","издание","источник"); val doi=col("doi"); val url=col("url","ссылка","адрес"); val ab=col("abstract","аннотация","резюме")
        if(ti<0) throw IllegalArgumentException("В CSV не найден столбец с названием публикации.")
        return lines.drop(1).map { line ->
            val c = splitCsv(line, delimiter)
            val get: (Int) -> String = { i -> if (i >= 0) c.getOrNull(i).orEmpty() else "" }
            Row(get(ti), get(au), get(yr).take(4).toIntOrNull(), get(jo), get(doi), get(url), get(ab))
        }
    }

    private fun splitCsv(line:String, delimiter:Char):List<String>{
        val out= mutableListOf<String>(); val b=StringBuilder(); var quoted=false; var i=0
        while(i<line.length){ val ch=line[i]; if(ch=='"'){ if(quoted && i+1<line.length && line[i+1]=='"'){b.append('"');i++} else quoted=!quoted } else if(ch==delimiter && !quoted){out+=b.toString().trim();b.setLength(0)} else b.append(ch); i++ }; out+=b.toString().trim(); return out
    }
    private fun normalizeHeader(s:String)=s.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}]+"),"")
    private fun clean(s:String)=s.replace(Regex("<[^>]+>")," ").replace(Regex("\\s+")," ").trim()
}
