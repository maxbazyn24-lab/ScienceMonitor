package ru.sciencemonitor.data
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import ru.sciencemonitor.R
class WeeklySearchWorker(appContext:Context,params:WorkerParameters):CoroutineWorker(appContext,params){
 override suspend fun doWork():Result {
  return try {
  val prefs=applicationContext.getSharedPreferences("science_monitor_settings",0)
  if(!prefs.getBoolean("weekly",false)) return Result.success()
  val topics=prefs.getString("topics","гидробиология\nэкология морей").orEmpty().lines().map{it.trim()}.filter{it.isNotBlank()}.take(10)
  val includeRussian=prefs.getBoolean("russian_sources",false)
  val enabled=setOf("OpenAlex","Crossref","Europe PMC","Semantic Scholar").filter{prefs.getBoolean("source_$it",true)}.toMutableSet().apply{if(includeRussian)add("OpenAlex RU")}.toSet()
  val repo=PublicationRepository(ScienceDatabase.get(applicationContext).publicationDao());var total=0
  topics.forEach { total+=repo.search(it,enabled,prefs.getInt("limit",50),includeRussian=includeRussian).received }
  if(prefs.getBoolean("notifications",true)) notifyUser(total)
  Result.success()
  } catch(e:Exception) { Result.retry() }
 }
 private fun notifyUser(count:Int){
  val manager=applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
  if(Build.VERSION.SDK_INT>=26) manager.createNotificationChannel(NotificationChannel("science_monitor","Science Monitor",NotificationManager.IMPORTANCE_DEFAULT))
  val n=NotificationCompat.Builder(applicationContext,"science_monitor").setSmallIcon(R.drawable.ic_stat_science).setContentTitle("Science Monitor: поиск завершён").setContentText("Новых библиографических записей получено: $count").setPriority(NotificationCompat.PRIORITY_DEFAULT).build()
  try{NotificationManagerCompat.from(applicationContext).notify(1001,n)}catch(_:SecurityException){}
 }
}
