package ru.sciencemonitor.data
import ru.sciencemonitor.network.ApiFactory

class PublicationRepository(private val dao:PublicationDao) {
 suspend fun search(query:String, enabled:Set<String>, limit:Int=50, additionalQueries:List<String> = emptyList(), includeRussian:Boolean = false):SearchReport {
  require(query.isNotBlank()) { "Введите поисковый запрос" }
  val queryVariants = (listOf(query) + additionalQueries).map { it.trim() }.filter { it.isNotBlank() }.distinct().take(6)
  val counts=linkedMapOf<String,Int>(); val errors=mutableListOf<String>()
  if (enabled.isEmpty()) return SearchReport(0, emptyMap(), listOf("В настройках не включён ни один источник поиска"))
  suspend fun run(source:String, block:suspend(String)->List<Publication>) {
   if(source !in enabled) return
   val uniqueRows=linkedMapOf<String,Publication>()
   queryVariants.forEach { variant ->
    try { block(variant).take(limit).forEach { row -> uniqueRows.putIfAbsent(row.deduplicationKey,row) } }
    catch(e:Exception) { errors += "$source [$variant]: ${e.message?.take(100) ?: "ошибка соединения"}" }
   }
   dao.insertAll(uniqueRows.values.toList())
   counts[source]=uniqueRows.size
  }
  run("OpenAlex") { variant -> ApiFactory.openAlex.searchWorks(variant,limit).results.mapNotNull { w ->
   val title=w.title?.takeIf{it.isNotBlank()}?:return@mapNotNull null; val doi=w.doi?.substringAfter("doi.org/")
   Publication(doi?.let{normalizeDoi(it)}?:fallbackKey(title,w.publication_year),title,w.authorships.mapNotNull{it.author?.display_name}.joinToString("; "),w.publication_year,w.primary_location?.source?.display_name.orEmpty(),doi,landingPageUrl=doi?.let{"https://doi.org/$it"} ?: w.id,source="OpenAlex")
  } }
  // Russian-language pass is explicitly controlled by the user's Russian-sources switch.
  if (includeRussian) run("OpenAlex RU") { variant -> ApiFactory.openAlex.searchWorks(variant,limit,filter="language:ru").results.mapNotNull { w ->
   val title=w.title?.takeIf{it.isNotBlank()}?:return@mapNotNull null
   val doi=w.doi?.substringAfter("doi.org/")
   Publication(doi?.let{normalizeDoi(it)}?:fallbackKey(title,w.publication_year),title,w.authorships.mapNotNull{it.author?.display_name}.joinToString("; "),w.publication_year,w.primary_location?.source?.display_name.orEmpty(),doi,language="ru",landingPageUrl=doi?.let{"https://doi.org/$it"} ?: w.id,source="OpenAlex RU")
  } }
  run("Crossref") { variant -> ApiFactory.crossref.searchWorks(variant,limit).message.items.mapNotNull { w ->
   val title=w.title?.firstOrNull()?.takeIf{it.isNotBlank()}?:return@mapNotNull null; val doi=w.DOI
   Publication(doi?.let{normalizeDoi(it)}?:fallbackKey(title,w.`published`?.`date-parts`?.firstOrNull()?.firstOrNull()),title,w.author.orEmpty().mapNotNull{listOfNotNull(it.given,it.family).joinToString(" ").ifBlank{null}}.joinToString("; "),w.`published`?.`date-parts`?.firstOrNull()?.firstOrNull(),w.container_title?.firstOrNull().orEmpty(),doi,w.abstract.orEmpty(),landingPageUrl=w.URL,source="Crossref")
  } }
  run("Europe PMC") { variant -> ApiFactory.europePmc.search(variant,pageSize=limit).resultList.result.mapNotNull { w ->
   val title=w.title?.takeIf{it.isNotBlank()}?:return@mapNotNull null; val doi=w.doi
   Publication(doi?.let{normalizeDoi(it)}?:w.pmid?.let{"pmid:$it"}?:fallbackKey(title,w.firstPublicationDate?.take(4)?.toIntOrNull()),title,w.authorString.orEmpty(),w.firstPublicationDate?.take(4)?.toIntOrNull(),w.journalTitle.orEmpty(),doi,w.abstractText.orEmpty(),landingPageUrl=when { !w.pmcid.isNullOrBlank()->"https://europepmc.org/articles/${w.pmcid}"; !doi.isNullOrBlank()->"https://doi.org/$doi"; !w.pmid.isNullOrBlank()->"https://pubmed.ncbi.nlm.nih.gov/${w.pmid}/"; else->null },source="Europe PMC")
  } }
  run("Semantic Scholar") { variant -> ApiFactory.semanticScholar.search(variant,limit).data.mapNotNull { w ->
   val title=w.title?.takeIf{it.isNotBlank()}?:return@mapNotNull null
   val doi=w.externalIds?.get("DOI")
   Publication(doi?.let{normalizeDoi(it)}?:fallbackKey(title,w.year),title,w.authors.mapNotNull{it.name}.joinToString("; "),w.year,w.venue.orEmpty(),doi,w.abstract.orEmpty(),landingPageUrl=w.url ?: doi?.let{"https://doi.org/$it"},source="Semantic Scholar")
  } }
  val total=counts.values.sum()
  return SearchReport(total,counts,errors)
 }
}
private fun normalizeDoi(value:String):String = "doi:" + value.trim().lowercase().removePrefix("https://doi.org/").removePrefix("http://doi.org/").removePrefix("doi:")
private fun fallbackKey(title:String,year:Int?):String = "title:" + title.lowercase().replace(Regex("[^\\p{L}\\p{N}]+")," ").trim() + ":" + (year?.toString()?:"")
data class SearchReport(val received:Int,val bySource:Map<String,Int>,val errors:List<String>)
