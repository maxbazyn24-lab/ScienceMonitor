package ru.sciencemonitor

import android.Manifest
import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Toast
import android.os.Build
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Image
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.room.Room
import kotlinx.coroutines.launch
import ru.sciencemonitor.data.*
import ru.sciencemonitor.sources.BibliographyImport
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy = androidx.compose.ui.graphics.Color(0xFF123B70)
private val Blue = androidx.compose.ui.graphics.Color(0xFF1769C2)
private val PaleBlue = androidx.compose.ui.graphics.Color(0xFFF2F7FD)
private val Ink = androidx.compose.ui.graphics.Color(0xFF172B45)

class MainActivity:ComponentActivity(){ override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); SearchScheduler.scheduleWeekly(this); setContent { MaterialTheme(colorScheme=lightColorScheme(primary=Blue,onPrimary=androidx.compose.ui.graphics.Color.White,secondary=androidx.compose.ui.graphics.Color(0xFF4D86C8),background=PaleBlue,surface=androidx.compose.ui.graphics.Color.White,onSurface=Ink),typography=Typography()) { ScienceMonitorApp() } } } }

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun ScienceMonitorApp(){
 val context= LocalContext.current
 val dao= remember { ScienceDatabase.get(context).publicationDao() }
 val repository= remember { PublicationRepository(dao) }
 val prefs= remember { context.getSharedPreferences("science_monitor_settings",0) }
 val publications by dao.observeAll().collectAsState(initial= emptyList())
 val scope= rememberCoroutineScope()
 var tab by remember { mutableIntStateOf(0) }
 var query by remember { mutableStateOf("") }
 var queryVariants by remember { mutableStateOf("") }
 var status by remember { mutableStateOf("Введите тему и запустите поиск") }
 var busy by remember { mutableStateOf(false) }
 val importLauncher=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){ uri:Uri? ->
  if(uri!=null) scope.launch { try {
   val bytes=context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Не удалось прочитать файл")
   val name=uri.lastPathSegment?.substringAfterLast('/') ?: "bibliography.csv"
   val imported=BibliographyImport.parse(bytes,name)
   val before=dao.count()
   dao.insertAll(imported)
   val added=dao.count()-before
   status="Распознано: ${imported.size}; добавлено в библиотеку: $added. Дубли пропущены."
  } catch(e:Exception){ status="Ошибка импорта: ${e.message ?: "неподдерживаемый файл"}" } }
 }
 val exportLauncher= rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")){ uri:Uri? ->
  if(uri!=null) scope.launch { try { context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { out ->
   out.write("\uFEFFНазвание;Авторы;Год;Журнал;DOI;Источник;Ссылка;Аннотация\r\n")
   publications.forEach { p -> out.write(listOf(p.title,p.authors,p.publicationYear?.toString().orEmpty(),p.journal,p.doi.orEmpty(),p.source,p.landingPageUrl.orEmpty(),p.abstractText).joinToString(";"){"\"${it.replace("\"","\"\"").replace("\n"," ") }\""}+"\r\n") }
  }; status="Экспортировано записей: ${publications.size}" } catch(e:Exception){status="Ошибка экспорта: ${e.message}"} }
 }
 Scaffold(containerColor=PaleBlue,topBar={ TopAppBar(title={ Text("Science Monitor",fontWeight=FontWeight.Bold,color=androidx.compose.ui.graphics.Color.White) },navigationIcon={ Icon(Icons.Default.Menu,null,tint=androidx.compose.ui.graphics.Color.White,modifier=Modifier.padding(start=16.dp)) },actions={ IconButton(onClick={tab=3}){Icon(Icons.Default.Settings,"Настройки",tint=androidx.compose.ui.graphics.Color.White)} },colors=TopAppBarDefaults.topAppBarColors(containerColor=Navy)) },bottomBar={ NavigationBar(containerColor=androidx.compose.ui.graphics.Color.White,contentColor=Blue) { NavigationBarItem(selected=tab==0,onClick={tab=0},icon={Icon(Icons.Default.Search,null)},label={Text("Поиск")}); NavigationBarItem(selected=tab==1,onClick={tab=1},icon={Icon(Icons.Default.Bookmarks,null)},label={Text("Библиотека")}); NavigationBarItem(selected=tab==2,onClick={tab=2},icon={Icon(Icons.Default.BarChart,null)},label={Text("Анализ")}); NavigationBarItem(selected=tab==3,onClick={tab=3},icon={Icon(Icons.Default.Settings,null)},label={Text("Настройки")}) } }) { padding ->
  when(tab){
   0 -> LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
    item { ElevatedCard(Modifier.fillMaxWidth(),colors=CardDefaults.elevatedCardColors(containerColor=Blue),shape=MaterialTheme.shapes.extraLarge) { Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) { Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)) { Surface(shape=MaterialTheme.shapes.large,color=androidx.compose.ui.graphics.Color.White.copy(alpha=.16f),modifier=Modifier.size(54.dp)) { Box(contentAlignment=androidx.compose.ui.Alignment.Center) { Image(painterResource(R.drawable.ic_science_monitor),contentDescription="Science Monitor",modifier=Modifier.size(54.dp)) } }; Column { Text("Science Monitor",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold,color=androidx.compose.ui.graphics.Color.White); Text("Поиск и анализ научных публикаций",style=MaterialTheme.typography.bodyMedium,color=androidx.compose.ui.graphics.Color.White.copy(alpha=.88f)) } } } } }
    item { Text("Найдите научные публикации",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=Ink); Text("По теме, автору, DOI или ключевым словам",style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant) }
    item { Card(Modifier.fillMaxWidth(),shape=MaterialTheme.shapes.extraLarge,colors=CardDefaults.cardColors(containerColor=androidx.compose.ui.graphics.Color.White)) { OutlinedTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth(),label={Text("Поисковый запрос")},placeholder={Text("Например: Palaemon macrodactylus")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=false,minLines=2,shape=MaterialTheme.shapes.extraLarge) } }
    item { OutlinedTextField(value=queryVariants,onValueChange={queryVariants=it},modifier=Modifier.fillMaxWidth(),label={Text("Дополнительные варианты на русском / английском")},placeholder={Text("Восточная травяная креветка\nраспространение креветок в Азовском море")},supportingText={Text("Каждый вариант — с новой строки. Можно указать перевод, синоним или латинское название.")},singleLine=false,minLines=2) }
    item { Button(onClick={ if(query.isNotBlank()&&!busy){busy=true;status="Выполняется поиск…";scope.launch { val includeRussian=prefs.getBoolean("russian_sources",false); val selected= setOf("OpenAlex","Crossref","Europe PMC","Semantic Scholar").filter { prefs.getBoolean("source_$it",true) }.toMutableSet().apply { if(includeRussian) add("OpenAlex RU") }; val variants=queryVariants.lines().flatMap{it.split(';')}.map{it.trim()}.filter{it.isNotBlank()}; try { val report=repository.search(query.trim(),selected,prefs.getInt("limit",50),variants,includeRussian); status="Получено ${report.received} записей. По источникам: ${report.bySource.entries.joinToString { "${it.key}: ${it.value}" }}"; if(report.errors.isNotEmpty()) status += "\nОшибки: ${report.errors.joinToString("; ")}" } catch(e:Exception){status="Поиск не выполнен: ${e.message}"};busy=false } } },enabled=!busy&&query.isNotBlank(),modifier=Modifier.fillMaxWidth().height(54.dp),shape=MaterialTheme.shapes.large) { if(busy) CircularProgressIndicator(Modifier.size(18.dp),strokeWidth=2.dp,color=androidx.compose.ui.graphics.Color.White) else Icon(Icons.Default.Search,null); Spacer(Modifier.width(8.dp));Text("Найти публикации",fontWeight=FontWeight.Bold) } }
    item { OutlinedButton(onClick={ if(query.isNotBlank()) context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://cyberleninka.ru/search?q="+Uri.encode(query.trim())))) },enabled=query.isNotBlank(),modifier=Modifier.fillMaxWidth()) { Text("Искать в КиберЛенинке") } }
    item { OutlinedButton(onClick={ if(query.isNotBlank()) { val clipboard=context.getSystemService(ClipboardManager::class.java); clipboard?.setPrimaryClip(ClipData.newPlainText("Science Monitor search",query.trim())); context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://elibrary.ru/"))); Toast.makeText(context,"Запрос скопирован. Войдите в eLIBRARY.RU и вставьте его в поиск.",Toast.LENGTH_LONG).show() } },enabled=query.isNotBlank(),modifier=Modifier.fillMaxWidth()) { Text("Скопировать запрос и открыть eLIBRARY.RU") } }
    item { OutlinedButton(onClick={importLauncher.launch(arrayOf("text/*","application/octet-stream","application/x-research-info-systems"))},modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.FileOpen,null); Spacer(Modifier.width(8.dp)); Text("Импортировать файл публикаций из eLIBRARY") } }
    item { Text("После поиска на eLIBRARY.RU сохраните/экспортируйте список публикаций в RIS, BibTeX или CSV (если такой экспорт доступен для выбранной выдачи), затем выберите файл здесь. Поддержка форматов не означает, что eLIBRARY гарантированно предоставляет каждый из них.",style=MaterialTheme.typography.bodySmall) }
    item { Text("eLIBRARY открывается во внешнем браузере: войдите в личный кабинет, если сессия ещё не активна, затем выполните поиск. Пароль приложение не запрашивает и не сохраняет. Автоматическое извлечение выдачи из личного кабинета не выполняется.",style=MaterialTheme.typography.bodySmall) }
    item { ElevatedCard(Modifier.fillMaxWidth(),shape=MaterialTheme.shapes.large,colors=CardDefaults.elevatedCardColors(containerColor=androidx.compose.ui.graphics.Color.White)){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Icon(Icons.Default.History,null,tint=Blue);Spacer(Modifier.width(8.dp));Text("Последний поиск",fontWeight=FontWeight.SemiBold)};Text(status,color=Ink);Text("Результаты сохраняются на устройстве и доступны без интернета.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}} }
    item { Text("Популярные темы",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=Ink) }
    items(listOf("Гидробиология","Экология морей","Микропластик","Инвазивные виды","Изменение климата","Palaemon macrodactylus")){ topic -> AssistChip(onClick={query=topic},label={Text(topic)},colors=AssistChipDefaults.assistChipColors(containerColor=androidx.compose.ui.graphics.Color.White,labelColor=Navy)) }
    item { Text("Автоматические источники: OpenAlex, Crossref, Europe PMC/PubMed и Semantic Scholar. При включённом переключателе русскоязычных источников выполняется дополнительный поиск OpenAlex с языковым фильтром ru. Российские сайты открываются отдельно в браузере.",style=MaterialTheme.typography.bodySmall) }
   }
   1 -> LazyColumn(Modifier.fillMaxSize().padding(padding).padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
    item { Text("Библиотека",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("Ваши сохранённые научные публикации",color=MaterialTheme.colorScheme.onSurfaceVariant); ElevatedCard(colors=CardDefaults.elevatedCardColors(containerColor=Blue),shape=MaterialTheme.shapes.large){Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Icon(Icons.Default.MenuBook,null,tint=androidx.compose.ui.graphics.Color.White,modifier=Modifier.size(30.dp));Spacer(Modifier.width(12.dp));Column{Text("Личная научная библиотека",color=androidx.compose.ui.graphics.Color.White,fontWeight=FontWeight.SemiBold);Text("Сохранено: ${publications.size}",color=androidx.compose.ui.graphics.Color.White.copy(alpha=.9f))}}} }
    item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={exportLauncher.launch("ScienceMonitor_${SimpleDateFormat("yyyyMMdd_HHmm",Locale.US).format(Date())}.csv")},enabled=publications.isNotEmpty()){Icon(Icons.Default.FileDownload,null);Text("Экспорт CSV")}; OutlinedButton(onClick={scope.launch { dao.clearAll();status="Локальная библиотека очищена" }},enabled=publications.isNotEmpty()){Text("Очистить")}} }
    if(publications.isEmpty()) item { Text("Публикаций пока нет. Выполните поиск на вкладке «Поиск».") }
    items(publications,key={it.deduplicationKey}) { p -> ElevatedCard(Modifier.fillMaxWidth(),shape=MaterialTheme.shapes.large,colors=CardDefaults.elevatedCardColors(containerColor=androidx.compose.ui.graphics.Color.White)){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){Text(p.title,fontWeight=FontWeight.SemiBold);Text(listOf(p.authors,p.publicationYear?.toString(),p.journal).filter{!it.isNullOrBlank()}.joinToString(" · "),style=MaterialTheme.typography.bodySmall);Text("Источник: ${p.source}${p.doi?.let{" · DOI: $it"}.orEmpty()}",style=MaterialTheme.typography.labelSmall);if(p.abstractText.isNotBlank()) Text(p.abstractText.replace(Regex("<[^>]*>"),"").take(500),style=MaterialTheme.typography.bodySmall);p.landingPageUrl?.let { TextButton(onClick={context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(it)))}){Text("Открыть публикацию")} } } } }
   }
   2 -> AnalysisScreen(padding,publications)
   else -> SettingsScreen(padding,prefs,{SearchScheduler.scheduleWeekly(context);status="Настройки сохранены"})
  }
 }
}

@Composable private fun SettingsScreen(padding:PaddingValues,prefs:android.content.SharedPreferences,onSaved:()->Unit){
 val context= LocalContext.current
 var openAlex by remember { mutableStateOf(prefs.getBoolean("source_OpenAlex",true)) };var russianSources by remember { mutableStateOf(prefs.getBoolean("russian_sources",false)) };var crossref by remember { mutableStateOf(prefs.getBoolean("source_Crossref",true)) };var europe by remember { mutableStateOf(prefs.getBoolean("source_Europe PMC",true)) };var semantic by remember { mutableStateOf(prefs.getBoolean("source_Semantic Scholar",true)) }
 var weekly by remember { mutableStateOf(prefs.getBoolean("weekly",false)) };var notifications by remember { mutableStateOf(prefs.getBoolean("notifications",true)) };var limit by remember { mutableFloatStateOf(prefs.getInt("limit",50).toFloat()) };var topics by remember { mutableStateOf(prefs.getString("topics","гидробиология\nэкология морей")?:"") }
 val notificationPermission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){ granted -> notifications=granted; prefs.edit().putBoolean("notifications",granted).apply() }
 LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
  item { Text("Настройки",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold); Text("Управление источниками и параметрами поиска",color=MaterialTheme.colorScheme.onSurfaceVariant) }
  item { Text("Источники поиска",style=MaterialTheme.typography.titleMedium) }
  item { SettingSwitch("OpenAlex — международный поиск",openAlex){openAlex=it;prefs.edit().putBoolean("source_OpenAlex",it).apply()} }
  item { SettingSwitch("Crossref",crossref){crossref=it;prefs.edit().putBoolean("source_Crossref",it).apply()} }
  item { SettingSwitch("Europe PMC / PubMed",europe){europe=it;prefs.edit().putBoolean("source_Europe PMC",it).apply()} }
  item { SettingSwitch("Semantic Scholar",semantic){semantic=it;prefs.edit().putBoolean("source_Semantic Scholar",it).apply()} }
  item { Divider(); Text("Российские источники",style=MaterialTheme.typography.titleMedium) }
  item { SettingSwitch("Русскоязычные источники",russianSources){russianSources=it;prefs.edit().putBoolean("russian_sources",it).apply()} }
  item { Text("При включении выполняется дополнительный запрос к OpenAlex с фильтром языка публикации ru. Для остальных баз приложение также использует введённые русские варианты запроса.",style=MaterialTheme.typography.bodySmall) }
  item { Text("КиберЛенинка: в этой версии поиск выполняется на официальном сайте, без автоматического сбора страниц.") }
  item { Button(onClick={ context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://cyberleninka.ru/search"))) }){Text("Открыть поиск КиберЛенинки")} }
  item { Text("eLIBRARY.RU: войдите в личный кабинет во внешнем браузере. Science Monitor не получает логин/пароль и не читает закрытую сессию. Для добавления результатов используйте экспорт библиографических записей с сайта, если он доступен, затем импортируйте RIS, BibTeX или CSV через вкладку «Поиск».") }
  item { Button(onClick={ context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://elibrary.ru/"))) }){Text("Открыть eLIBRARY.RU и войти")} }
  item { Divider();Text("Перечень ВАК",style=MaterialTheme.typography.titleMedium);Text("ВАК — это перечень рецензируемых журналов, а не отдельная база статей. Для подтверждения статуса журнала и специальности 1.5.16 сверяйте название и ISSN с актуальной официальной редакцией перечня. Автоматическое подтверждение статуса и категории К1/К2/К3 в этой сборке пока не реализовано.");Button(onClick={context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://vak.gisnauka.ru/documents/editions")))}){Text("Открыть официальный перечень ВАК")} }
  item { Divider();Text("Параметры поиска",style=MaterialTheme.typography.titleMedium);Text("Максимум результатов на источник: ${limit.toInt()}");Slider(value=limit,onValueChange={limit=it},valueRange=10f..100f,steps=8,onValueChangeFinished={prefs.edit().putInt("limit",limit.toInt()).apply()}) }
  item { Text("Темы для автоматического поиска",style=MaterialTheme.typography.titleMedium);OutlinedTextField(value=topics,onValueChange={topics=it;prefs.edit().putString("topics",it).apply()},modifier=Modifier.fillMaxWidth(),minLines=3,label={Text("Одна тема на строку")}) }
  item { SettingSwitch("Еженедельный поиск",weekly){weekly=it;prefs.edit().putBoolean("weekly",it).apply();onSaved()} }
  item { SettingSwitch("Уведомления",notifications){ enabled -> if(enabled && Build.VERSION.SDK_INT>=33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS) else {notifications=enabled;prefs.edit().putBoolean("notifications",enabled).apply()} } }
  item { Text("Локальное хранение",style=MaterialTheme.typography.titleMedium);Text("Библиотека публикаций хранится в базе данных на устройстве. Интернет нужен для поиска новых записей. Уже сохранённые записи доступны офлайн.") }
  item { Text("Анализ публикаций",style=MaterialTheme.typography.titleMedium);Text("В текущей сборке доступна библиографическая обработка и предварительная разметка по тексту аннотации. Полноценная локальная языковая модель пока не встроена.") }
  item { Text("Science Monitor · версия 0.7.0",style=MaterialTheme.typography.labelSmall) }
 }
}
@Composable private fun SettingSwitch(title:String,checked:Boolean,onChange:(Boolean)->Unit){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(title,modifier=Modifier.weight(1f));Switch(checked=checked,onCheckedChange=onChange)}}

@Composable private fun AnalysisScreen(padding:PaddingValues, publications:List<Publication>){
 val terms= remember(publications){
  val stop=setOf("для","при","или","как","что","это","the","and","with","from","into","study","using","based","в","на","по","из","к","о","и","а","не","данных","метод","исследование")
  publications.flatMap{(it.title+" "+it.abstractText).lowercase().split(Regex("[^\\p{L}\\p{N}]+"))}.filter{it.length>=4&&it !in stop}.groupingBy{it}.eachCount().entries.sortedByDescending{it.value}.take(20)
 }
 LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{Text("Анализ",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("Локальная статистическая обработка названий и аннотаций. Это не генеративный ИИ и не экспертная оценка содержания.",style=MaterialTheme.typography.bodySmall)}
  item{ElevatedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("База для анализа",fontWeight=FontWeight.SemiBold);Text("Публикаций: ${publications.size}");Text("С аннотациями: ${publications.count{it.abstractText.isNotBlank()}}")}}}
  item{Text("Часто встречающиеся термины",style=MaterialTheme.typography.titleMedium)}
  if(terms.isEmpty()) item{Text("Недостаточно данных. Сначала выполните поиск публикаций.")}
  items(terms){term->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(term.key);Text("${term.value}",fontWeight=FontWeight.SemiBold)}}
  item{Text("Ограничения",style=MaterialTheme.typography.titleMedium);Text("Частота слов не устанавливает научную новизну, достоверность результатов, методы исследования или релевантность вашей теме. Для полноценного ИИ-анализа потребуется локальная языковая модель либо отдельно подключаемый внешний сервис.") }
 }
}
