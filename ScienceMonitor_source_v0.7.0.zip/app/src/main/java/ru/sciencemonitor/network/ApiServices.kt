package ru.sciencemonitor.network

import retrofit2.http.GET
import retrofit2.http.Query

interface OpenAlexService {
    @GET("works") suspend fun searchWorks(@Query("search") query:String,@Query("per-page") perPage:Int=50,@Query("sort") sort:String="publication_date:desc",@Query("filter") filter:String?=null):OpenAlexResponse
}
interface CrossrefService {
    @GET("works") suspend fun searchWorks(@Query("query") query:String,@Query("rows") rows:Int=50,@Query("sort") sort:String="published",@Query("order") order:String="desc"):CrossrefResponse
}
interface EuropePmcService {
    @GET("MED/search") suspend fun search(@Query("query") query:String,@Query("format") format:String="json",@Query("pageSize") pageSize:Int=50,@Query("resultType") resultType:String="core"):EuropePmcResponse
}
data class OpenAlexResponse(val results:List<OpenAlexWork> = emptyList())
data class OpenAlexWork(val id:String?=null,val doi:String?=null,val title:String?=null,val publication_year:Int?=null,val authorships:List<OpenAlexAuthorship> = emptyList(),val primary_location:OpenAlexLocation?=null)
data class OpenAlexAuthorship(val author:OpenAlexAuthor?=null)
data class OpenAlexAuthor(val display_name:String?=null)
data class OpenAlexLocation(val source:OpenAlexSource?=null)
data class OpenAlexSource(val display_name:String?=null)
data class CrossrefResponse(val message:CrossrefMessage=CrossrefMessage())
data class CrossrefMessage(val items:List<CrossrefWork> = emptyList())
data class CrossrefWork(val DOI:String?=null,val title:List<String>?=null,val author:List<CrossrefAuthor>?=null,val published:CrossrefDate?=null,val container_title:List<String>?=null,val URL:String?=null,val abstract:String?=null)
data class CrossrefAuthor(val given:String?=null,val family:String?=null)
data class CrossrefDate(val `date-parts`:List<List<Int>>?=null)
data class EuropePmcResponse(val resultList:EuropePmcResultList=EuropePmcResultList())
data class EuropePmcResultList(val result:List<EuropePmcRecord> = emptyList())
data class EuropePmcRecord(val title:String?=null,val authorString:String?=null,val firstPublicationDate:String?=null,val journalTitle:String?=null,val doi:String?=null,val pmid:String?=null,val abstractText:String?=null,val pmcid:String?=null)


interface SemanticScholarService {
    @retrofit2.http.Headers("Accept: application/json")
    @GET("paper/search")
    suspend fun search(
        @Query("query") query: String,
        @Query("limit") limit: Int = 50,
        @Query("fields") fields: String = "title,authors,year,venue,abstract,externalIds,url,publicationDate"
    ): SemanticScholarResponse
}
data class SemanticScholarResponse(val data: List<SemanticScholarPaper> = emptyList())
data class SemanticScholarPaper(
    val title: String? = null,
    val authors: List<SemanticScholarAuthor> = emptyList(),
    val year: Int? = null,
    val venue: String? = null,
    val abstract: String? = null,
    val externalIds: Map<String, String>? = null,
    val url: String? = null
)
data class SemanticScholarAuthor(val name: String? = null)
